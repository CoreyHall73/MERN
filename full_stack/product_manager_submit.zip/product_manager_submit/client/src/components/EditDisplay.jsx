import React from 'react'
import Edit from "./views/Edit"

const EditDisplay = () => {
    return (
    <fieldset>
        <legend>EditDisplay.jsx</legend>
        <Edit />
    </fieldset>
    )
}

export default EditDisplay