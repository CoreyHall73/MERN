import Display from "./components/Display"
import './App.css';

function App() {
  return (
    <div className="App">
      <Display />
    </div>
  );
}

export default App;
