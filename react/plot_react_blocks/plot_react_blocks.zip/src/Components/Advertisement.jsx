import React, { Component } from 'react';
import styles from './css/Box.module.css';
    
    
class Advertisement extends Component {
    render() {
        return <div className={styles.Advertisement}>Advertisement</div>;
    }
}
    
export default Advertisement;