import React, { Component } from 'react';
import styles from './css/Box.module.css';
    
    
class Header extends Component {
    render() {
        return <div className={styles.topNav}>Header</div>;
    }
}
    
export default Header;
