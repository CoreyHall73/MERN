import React, { Component } from 'react';
import styles from './css/Box.module.css';
    
    
class Navigation extends Component {
    render() {
        return <div className={styles.sideNav}>Navigation</div>;
    }
}
    
export default Navigation;