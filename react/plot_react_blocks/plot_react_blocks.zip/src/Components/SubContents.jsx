import React, { Component } from 'react';
import styles from './css/Box.module.css';
    
class SubContents extends Component {
    render() {
        return <div className={styles.SubContents}>SubContents</div>;
    }
}
    
export default SubContents;